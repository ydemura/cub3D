//
//  algoritm.h
//  cubic_xcode_part
//
//  Created by Yuliia Demura on 5/6/21.
//  Copyright © 2021 Yuliia Demura. All rights reserved.
//

#ifndef algoritm_h
#define algoritm_h

// #include "mlx.h"
//#include "/Users/ydemura/Desktop/cubik/mlx/mlx.h"

#endif /* algoritm_h */
