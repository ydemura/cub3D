//
//  gnl.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 25/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef gnl_h
#define gnl_h

#include "get_next_line.h"

int		exam_get_next_line(int fd, char **line);

#endif /* gnl_h */
