//
//  form_header_structure.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 25/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef form_header_structure_h
#define form_header_structure_h

#include "initiate_struct.h"

int	form_header_structure(int fd, t_header_info *head);
int	check_if_string_is_map(char *str);

#endif /* form_header_structure.h */
