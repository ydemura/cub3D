//
//  colours.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 21/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef colours_h
#define colours_h

#include "initiate_struct.h"

int color_check_collection(t_header_info *head, char *str);

#endif /* colours_h */
