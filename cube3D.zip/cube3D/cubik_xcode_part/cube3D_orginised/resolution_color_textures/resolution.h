//
//  resolution.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 21/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef resolution_h
#define resolution_h

#include "initiate_struct.h"

int     collect_resolution(t_header_info *head, char *str);

#endif /* resolution_h */
