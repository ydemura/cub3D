//
//  textures.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 25/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef textures_h
#define textures_h

#include "initiate_struct.h"

int    error_check_str_and_collect_path(char *s, t_header_info *head);

#endif /* textures_h */
