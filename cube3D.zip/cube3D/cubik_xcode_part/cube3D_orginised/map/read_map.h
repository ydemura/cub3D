//
//  read_map.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 25/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef read_map_h
#define read_map_h

typedef	struct	s_map_size
{
	int len_rows;
	int len_cols;

	int map_error;
	int player_flag;
	t_error_handling errors_parsing;
}				t_map_size;

int        read_map(int fd, t_map_size *map_size);

#endif /* read_map_h */
