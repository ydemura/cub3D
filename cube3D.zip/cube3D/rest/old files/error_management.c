//
//  error_management.c
//  tests
//
//  Created by Yuliia Demura on 4/8/21.
//  Copyright © 2021 Yuliia Demura. All rights reserved.
//

#include "header_all.h"

int    error_flag_check(t_errors *error)
{
//
//    if (error->duplicate_elements)
//        return (1);
//    else if (error->wrong_element_identifier)
//        return (1);
//    else if (error->info_not_collected_map_found)
//        return (1);
//	else if (error->eof_not_collected_information)
//        return (1);
//    else if (error->wrong_sequence_in_r_c_f)
//        return (1);
//
//
//	else if (error->no_space_between_identifier_and_information)
//		return (1);
//
//	else if (error->map_is_not_last)
//    {
//        return (1);
//    }
//
//    else if (error->flags_collected_but_later_dupl)
//    {
//        return (1);
//    }
//
//	else if (error->wrong_char_in_map)
//    {
//        return (1);
//    }
//	else if (error->malloc_crush)
//    {
//        return (1);
//    }
//	else if (error->not_space_in_tail_of_path)
//    {
//        return (1);
//    }
//
//    else
//        return (0);
    
    return (0);
}

int	error_management(t_game_state *gstate)
{
//	if (gstate->head.error->info_not_collected_map_found == 1)
//		write_str("error message from: collect_info_from_header_map.c, 'find_element' \nnot enough elements in header before map,  invalid map\n");
//	if (gstate->head.error->wrong_element_identifier == 1)
//		write_str("error message from: collect_path_from_str.c \nwrong char in element identifier, invalid map\n");
//    if (gstate->head.error->duplicate_elements == 1)
//		write_str("error message from: collect_info_from_header_map.c \nduplicate element in header, invalid map\n");
//	if (gstate->head.error->eof_not_collected_information == 1)
//        write_str("error message from: collect_info_from_header_map.c \nend of the file reached, not all information collected, invalid map\n");
//    if (gstate->head.error->wrong_sequence_in_r_c_f == 1)
//        write_str("error message from: collect_info_from_header_map.c \nissue with collecting resolution/colours, invalid information, invalid map\n");
//
//
//
//	if (gstate->head.error->no_space_between_identifier_and_information == 1)
//	{
//		write_str("error message from: collect_info_from_str.c \nno space between identifier and information, invalid map\n");
//	}
//
//	if (gstate->head.error->map_is_not_last == 1)
//	{
//		write_str("error message from: read_map.c or collect_info_from_header_map.c \nmap is not the last element\n");
//	}
//    if (gstate->head.error->flags_collected_but_later_dupl == 1)
//    {
//        write_str("error message from: read_map.c \nall information collected but duplicate found in map section\n");
//    }
//	if (gstate->head.error->wrong_char_in_map == 1)
//	{
//		write_str("error message from:   write here   \n");
//	}
//
//	if (gstate->head.error->malloc_crush == 1)
//    {
//        write_str("error message:malloc crushed, oops\n");
//    }
//
//	if (gstate->head.error->not_space_in_tail_of_path == 1)
//	{
//		write_str("error message from collect_path_from_str.c: extra chars in the end of path, wrond map\n");
//	}
//
//
//	if (error_flag_check(gstate->head.error))
//		return (1);
//	else
		
		
	return (0);
}
