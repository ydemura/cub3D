#!/bin/bash

make
mv cubik_xcode_part/cubik_xcode_part/*.o cubik_xcode_part/cubik_xcode_part/object_files_can
# rm cubik_xcode_part/cubik_xcode_part/*.o

mv cubik_xcode_part/cubik_xcode_part/work_with_header/*.o cubik_xcode_part/cubik_xcode_part/object_files_can
# rm cubik_xcode_part/cubik_xcode_part/work_with_header/*.o

mv cubik_xcode_part/cubik_xcode_part/work_with_map/*.o cubik_xcode_part/cubik_xcode_part/object_files_can
# rm cubik_xcode_part/cubik_xcode_part/work_with_map/*.o

mv cubik_xcode_part/cubik_xcode_part/algoritm/*.o cubik_xcode_part/cubik_xcode_part/object_files_can
