/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   form_grid.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yuliia <yuliia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/31 19:48:46 by yuliia            #+#    #+#             */
/*   Updated: 2022/10/31 19:49:06 by yuliia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FORM_GRID_H
# define FORM_GRID_H

# include "parsing_gamestate.h"

int	form_grid(int fd, t_game_state *gstate);

# endif /* boarders_h */
