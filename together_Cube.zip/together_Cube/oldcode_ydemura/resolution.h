//
//  resolution.h
//  cubic_xcode_part
//
//  Created by Julia Demura on 21/10/2022.
//  Copyright © 2022 Yuliia Demura. All rights reserved.
//

#ifndef resolution_h
#define resolution_h

#include "initiate_data.h"

int     collect_resolution(t_data *data, char *str);

#endif /* resolution_h */
